'use strict';

exports.BattleScripts = {
	inherit: 'gen3',
};
